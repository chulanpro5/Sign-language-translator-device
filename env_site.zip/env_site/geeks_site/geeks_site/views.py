# HttpResponse is used to 
# pass the information  
# back to view 
from django.http import HttpResponse
from django.shortcuts import render 
from json import dumps 
  
# Defining a function which 
# will receive request and 
# perform task depending  
# upon function definition 
#def hello_geeks (request) : 
  
    # This will return Hello Geeks 
    # string as HttpResponse 
    #return HttpResponse("Hello Geeks")

def hello_geeks (request): 
    # create data dictionary 
    dataDictionary = { 
            'hello': 'World', 
            'geeks': 'forgeeks', 
            'ABC': 123, 
            456: 'abc', 
            14000605: 1, 
            'list': ['geeks', 4, 'geeks'], 
            'dictionary': {'you': 'can', 'send': 'anything', 3: 1} 
    } 
    # dump data 
    dataJSON = dumps(dataDictionary) 
    #return render(request, 'main / landing.html', {'data': dataJSON})
    return render(request, 'main/landing.html', {'data': dataJSON}) 

